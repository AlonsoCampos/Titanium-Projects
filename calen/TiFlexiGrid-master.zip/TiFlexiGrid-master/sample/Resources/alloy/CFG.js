module.exports = {
    dependencies: {
        tiflexigrid: "1.1"
    }
};